/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.infox.dal;

import java.sql.*;

/**
 *
 * @author sgadg
 */
public class ModuloConexao {
    //estabelecendo conexão com o banco de dados
    public static Connection conector(){
        java.sql.Connection conexao = null; //conexao nula
        //chamando o driver que eu importei para a biblioteca
        String driver = "com.mysql.cj.jdbc.Driver"; //tipo do banco de dados
        //Armazenando informações do banco
        String url = "jdbc:mysql://localhost:3306/dbinfox"; //caminho e nome do banco
        String user="root";
        String password = "";
        
        //estabelecendo conexão com o banco de dados
        try {
            Class.forName(driver);
            conexao = DriverManager.getConnection(url, user, password);
            return conexao;
        } catch (Exception e) {
            //System.out.println(e);//para esclarecer o erro, caso ocorra
            return null;
        }
    }
}
